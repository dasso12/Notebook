
package model;

import java.sql.*;

public class MConnection {
    private String database = "notebook";
    private String username = "root";
    private String password = "";
    private String hostname = "jdbc:mysql://localhost:3306/" + database;
    private Connection connection = null;

    public MConnection(){
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(hostname,username,password);
            
            if(connection != null)
            {
                System.out.println("CONNECTION SUCCCESSFULL " + hostname);
            }
        }  
        catch(ClassNotFoundException | SQLException ex)
        {
            System.out.println(ex.getMessage());
        }        
    }
    
    public Connection  connection(){
      return connection;
    }

    public void finallyConnection(){
      connection = null;
    }
}
