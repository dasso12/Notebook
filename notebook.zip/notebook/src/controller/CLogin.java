
package controller;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import model.*;
import  view.*;

public class CLogin implements ActionListener{
    private final VLogin vLogin;
    private MLogin mLogin;
    private final VMenu   vMenu;
    private String username;
    private String password;
   
    //CONTRUCTOR METHOD.
    public   CLogin(VLogin login, VMenu menu)
    {
        this.vLogin = login;
        this.vMenu  =  menu;
        this.vLogin.btnLogin.addActionListener(this);
    }
    
    //METHOD WHOSE CONTENT ARE CLIC EVENTS.
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vLogin.btnLogin)
        {
            mLogin = new MLogin();
            username = vLogin.txtUsername.getText();
            password = vLogin.txtPassword.getText();
          
            if(username.isEmpty() || password.isEmpty())
            {
                 System.out.println("THERE IS NOT VALUES");
            }
            else
            {
                mLogin.searchUser(username, password);
            }
        }
    }
}
