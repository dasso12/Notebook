package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import  view.*;

public class CMenu implements ActionListener{
    private final VAthlete vAthlete;
    private VMenu       vMenu;
    private VPerson     vPerson;
    //CONTRUCTOR METHOD.
    public   CMenu(VMenu menu, VAthlete athlete, VPerson person)  
    {
        this.vMenu    =    menu;
        this.vAthlete = athlete;
        this.vPerson  =  person;
        this.vMenu.btnVAthelete.addActionListener(this); 
        this.vMenu.btnVPerson.addActionListener(this); 
    }
    
    //METHOD WHOSE CONTENT ARE CLIC EVENTS.
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vMenu.btnVAthelete)
        {
            this.vAthlete.setVisible(true);
        }
        
        if(e.getSource() == vMenu.btnVPerson)
        {
            this.vPerson.setVisible(true);
        }
    }
}
