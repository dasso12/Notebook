package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import  view.*;
import model.*;

public class CAthlete implements ActionListener{
    MConnection conn;
    
    private final VAthlete vAthlete;
    private MAthlete mAthlete;
    private VMenu    vMenu;
    private String id_athlete;
    private String athlete_name;
    private String  fatherSurname;
    private String  motherSurname;
    private String gender;
    private String birthdate;
    private String  cellphone_number;
    private String  telephone_home;
    private String  email;
    private String  favorite_contact;

    
    public CAthlete(VAthlete athlete){
        this.vAthlete = athlete;
        this.vAthlete.btnInsertAthlete.addActionListener(this);
        this.vAthlete.btnDelelteAthlete.addActionListener(this);
        this.vAthlete.btnUpdateAthlete.addActionListener(this);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vAthlete.btnInsertAthlete)
        {
            try{
                mAthlete = new MAthlete();
                athlete_name = vAthlete.txtAthleteName.getText();
                fatherSurname = vAthlete.txtFatherSurname.getText();
                motherSurname = vAthlete.txtMotherSurname.getText();
                gender = vAthlete.txtGender.getText();
                birthdate = vAthlete.txtCumple.getText();
                cellphone_number = vAthlete.txtCel.getText();
                email = vAthlete.txtEmail.getText();
                telephone_home = vAthlete.txtPhone.getText();
                   if(athlete_name.isEmpty() || fatherSurname.isEmpty())
                {
                   JOptionPane.showMessageDialog(null,"THE NAME AND FATHER SURNAME ARE REQUIERED","WARNING",JOptionPane.ERROR_MESSAGE);
                   conn.finallyConnection();
                }
                else
                {
                   mAthlete.insertAthlete(athlete_name,fatherSurname, motherSurname, favorite_contact ,gender,birthdate, cellphone_number 
                   ,telephone_home, email);   
                }      
            }catch(Exception ex){
                                System.out.println(ex.getMessage());
            }
            
            if(e.getSource() == vAthlete.btnDelelteAthlete)
            {
                try{
                    mAthlete = new MAthlete();
                    id_athlete = String.valueOf(vAthlete.txtAthleteId.getText());
                    if(id_athlete.isEmpty())
                    {
                       JOptionPane.showMessageDialog(null,"WARNING, YOU SHOULD INSERT THE ID","WARNING",JOptionPane.ERROR_MESSAGE);
                            conn.finallyConnection();
                    }
                    else
                    {
                        mAthlete.deleteAthlete(id_athlete);
                    }
                }catch(Exception ex)
                {
                    System.out.println(ex.getMessage());

                }
            }
            
            if(e.getSource() == vAthlete.btnUpdateAthlete)
        {
            try
            {
                mAthlete = new MAthlete();
                id_athlete = String.valueOf(vAthlete.txtAthleteId.getText());
                athlete_name = vAthlete.txtAthleteName.getText();
                fatherSurname = vAthlete.txtFatherSurname.getText();
                motherSurname = vAthlete.txtMotherSurname.getText();
                favorite_contact = vAthlete.txtFavoriteCon.getText();
                gender = vAthlete.txtGender.getText();
                cellphone_number = vAthlete.txtCel.getText();
                telephone_home = vAthlete.txtPhone.getText();
                email = vAthlete.txtEmail.getText();
                
                if(id_athlete.isEmpty())
                {
                   JOptionPane.showMessageDialog(null,"WARNING, YOU SHOULD INSERT THE ID","WARNING",JOptionPane.ERROR_MESSAGE);
                   conn.finallyConnection();
                }
                else
                {
                   mAthlete.updateAthlete(id_athlete, athlete_name, fatherSurname, motherSurname, gender, favorite_contact , cellphone_number 
                   ,telephone_home,birthdate, email);   
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        }
        
        
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
