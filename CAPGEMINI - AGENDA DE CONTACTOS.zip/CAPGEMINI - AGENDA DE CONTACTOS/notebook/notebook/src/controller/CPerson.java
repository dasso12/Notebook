
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import  view.*;
import model.*;

public class CPerson implements ActionListener{
    MConnection conn;
    private final VPerson vPerson;
    private MPerson mPerson;
    private VMenu     vMenu;
    private String  id_person;  
    private String  name;  
    private String  fatherSurname;
    private String  motherSurname;
    private String  address;
    private String  favorite_contact;
    private String  occupation;
    private String  cellphone_number;
    private String  telephone_home;
    private String  email;
    
    //CONTRUCTOR METHOD.
    public   CPerson(VPerson person)
    {
        this.vPerson = person;
        this.vPerson.btnInsertPerson.addActionListener(this);
        this.vPerson.btnDeletePerson.addActionListener(this);
        this.vPerson.btnUpdatePerson.addActionListener(this);
    }
    
    //METHOD WHOSE CONTENT ARE CLIC EVENTS.
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vPerson.btnInsertPerson)
        {
            try
            {
                mPerson = new MPerson();
                name = vPerson.txtPersonName.getText();
                fatherSurname = vPerson.txtFatherSurname.getText();
                motherSurname = vPerson.txtMotherSurname.getText();
                address  = vPerson.txtAddress.getText();
                favorite_contact = vPerson.txtFavoriteContact.getText();
                occupation = vPerson.txtOccupation.getText();
                cellphone_number = vPerson.txtCellphone.getText();
                telephone_home = vPerson.txtPhoneHome.getText();
                email = vPerson.txtEmail.getText();
                if(name.isEmpty() || fatherSurname.isEmpty())
                {
                   JOptionPane.showMessageDialog(null,"THE NAME AND FATHER SURNAME ARE REQUIERED","WARNING",JOptionPane.ERROR_MESSAGE);
                   conn.finallyConnection();
                }
                else
                {
                   mPerson.insertPerson(name, fatherSurname, motherSurname, address, favorite_contact , occupation, cellphone_number 
                   ,telephone_home, email);   
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        if(e.getSource() == vPerson.btnDeletePerson)
        {
             try
            {
                mPerson = new MPerson();
                id_person = String.valueOf(vPerson.txtIdPerson.getText());
                if(id_person.isEmpty())
                {
                   JOptionPane.showMessageDialog(null,"WARNING, YOU SHOULD INSERT THE ID","WARNING",JOptionPane.ERROR_MESSAGE);
                   conn.finallyConnection();
                }
                else
                {
                    mPerson.deletePerson(id_person);
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        if(e.getSource() == vPerson.btnUpdatePerson)
        {
            try
            {
                mPerson = new MPerson();
                id_person = String.valueOf(vPerson.txtIdPerson.getText());
                name = vPerson.txtPersonName.getText();
                fatherSurname = vPerson.txtFatherSurname.getText();
                motherSurname = vPerson.txtMotherSurname.getText();
                address  = vPerson.txtAddress.getText();
                favorite_contact = vPerson.txtFavoriteContact.getText();
                occupation = vPerson.txtOccupation.getText();
                cellphone_number = vPerson.txtCellphone.getText();
                telephone_home = vPerson.txtPhoneHome.getText();
                email = vPerson.txtEmail.getText();
                if(id_person.isEmpty())
                {
                   JOptionPane.showMessageDialog(null,"WARNING, YOU SHOULD INSERT THE ID","WARNING",JOptionPane.ERROR_MESSAGE);
                   conn.finallyConnection();
                }
                else
                {
                   mPerson.updatePerson(id_person, name, fatherSurname, motherSurname, address, favorite_contact , occupation, cellphone_number 
                   ,telephone_home, email);   
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
    }
}

