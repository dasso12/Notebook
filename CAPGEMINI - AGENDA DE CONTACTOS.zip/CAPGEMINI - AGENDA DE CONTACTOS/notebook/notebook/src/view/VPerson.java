
package view;

public class VPerson extends javax.swing.JFrame {

    public VPerson() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        txtCellphone = new javax.swing.JTextField();
        txtAddress = new javax.swing.JTextField();
        txtOccupation = new javax.swing.JTextField();
        txtPersonName = new javax.swing.JTextField();
        txtFavoriteContact = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtMotherSurname = new javax.swing.JTextField();
        btnInsertPerson = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtIdPerson = new javax.swing.JTextField();
        txtFatherSurname = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnDeletePerson = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txtPhoneHome = new javax.swing.JTextField();
        btnUpdatePerson = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel7.setText("ADDRESS");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));
        getContentPane().add(txtCellphone, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 250, 184, -1));
        getContentPane().add(txtAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 184, -1));
        getContentPane().add(txtOccupation, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 184, -1));
        getContentPane().add(txtPersonName, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 184, -1));
        getContentPane().add(txtFavoriteContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 184, -1));

        jLabel3.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel3.setText("FATHER  SURNAME*");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel10.setFont(new java.awt.Font("HP Simplified", 0, 18)); // NOI18N
        jLabel10.setText("MENU PERSONA");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, -1));

        jLabel4.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel4.setText("MOTHER SURNAME");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, -1));

        jLabel5.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel5.setText("CELLPHONE NUMBER");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, -1, -1));
        getContentPane().add(txtMotherSurname, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 184, -1));

        btnInsertPerson.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        btnInsertPerson.setText("INSERT");
        getContentPane().add(btnInsertPerson, new org.netbeans.lib.awtextra.AbsoluteConstraints(356, 43, 148, 58));

        jLabel2.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel2.setText("ID ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));
        getContentPane().add(txtIdPerson, new org.netbeans.lib.awtextra.AbsoluteConstraints(159, 43, 184, -1));
        getContentPane().add(txtFatherSurname, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 184, -1));
        getContentPane().add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 310, 184, -1));

        jLabel6.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel6.setText("PHONE HOME");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, -1, -1));

        jLabel11.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel11.setText("OCCUPATION");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        jLabel8.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel8.setText("FAVORITE CONTACT");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        jLabel9.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel9.setText("EMAIL");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, -1, -1));

        btnDeletePerson.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        btnDeletePerson.setText("DELETE");
        getContentPane().add(btnDeletePerson, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 160, 148, 58));

        jLabel12.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        jLabel12.setText("NAME*");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));
        getContentPane().add(txtPhoneHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 184, -1));

        btnUpdatePerson.setFont(new java.awt.Font("HP Simplified", 0, 14)); // NOI18N
        btnUpdatePerson.setText("UPDATE");
        getContentPane().add(btnUpdatePerson, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 280, 148, 58));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VPerson().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnDeletePerson;
    public javax.swing.JButton btnInsertPerson;
    public javax.swing.JButton btnUpdatePerson;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    public javax.swing.JTextField txtAddress;
    public javax.swing.JTextField txtCellphone;
    public javax.swing.JTextField txtEmail;
    public javax.swing.JTextField txtFatherSurname;
    public javax.swing.JTextField txtFavoriteContact;
    public javax.swing.JTextField txtIdPerson;
    public javax.swing.JTextField txtMotherSurname;
    public javax.swing.JTextField txtOccupation;
    public javax.swing.JTextField txtPersonName;
    public javax.swing.JTextField txtPhoneHome;
    // End of variables declaration//GEN-END:variables
}
