
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import view.*;
import controller.*;
import javax.swing.JOptionPane;

public class MLogin extends MConnection{
    VMenu   menu = null;
    VLogin login = null;
    private String user_name;
    private String pass_name;
    
    private void screen(){
        VAthlete a = new VAthlete();
        VMenu    m = new    VMenu();
        VPerson  p = new  VPerson();
        CMenu   main = new CMenu( m,a, p);
        m.setVisible(true); 
     
        CPerson run  = new CPerson(p);
    }
    
    public void searchUser(String username, String password){
    menu  = new  VMenu();
    login = new VLogin();
    boolean exist = false;   
	try{
            PreparedStatement ps    = null;
            Connection conn = connection();
            String query = "SELECT * FROM login WHERE user_name = ? AND pass_name = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet res = ps.executeQuery();
            
            while(res.next()){
                exist = true;
                user_name = res.getString("user_name");
		pass_name = res.getString("pass_name");
            }
            
            if(user_name!= null && pass_name != null ){
                JOptionPane.showMessageDialog(null,"WELCOME TO NOTEBOOK","HELLO!",JOptionPane.ERROR_MESSAGE);
                menu.setVisible(true);
                this.screen();
                finallyConnection();
            }  
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"THE USER NOT EXIST",":(",JOptionPane.ERROR_MESSAGE);
        }
    }    
}

