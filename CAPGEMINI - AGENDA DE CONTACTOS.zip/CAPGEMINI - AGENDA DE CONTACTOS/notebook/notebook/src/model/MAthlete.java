
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class MAthlete extends MConnection{
    
    public Boolean insertAthlete(String athlete_name, String fatherSurname,String motherSurname, String gender, String favorite_contact, String birthdate 
    ,String cellphone_number, String telephone_home, String email){
        
        try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "INSERT INTO athlete (athlete_name, father_surname, mother_surname, gender, favorite_contact, birthdate,"
            + " cellphone_number, telephone_home, email) VALUES (?,?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setString(1, athlete_name);
            ps.setString(2, fatherSurname);
            ps.setString(3, motherSurname);
            ps.setString(4, gender);
            ps.setString(5, favorite_contact);
            ps.setString(6, birthdate);
            ps.setString(7, cellphone_number);
            ps.setString(8, telephone_home);
            ps.setString(9, email);
            ps.execute();
            JOptionPane.showMessageDialog(null,"ATHLETE INSERT","SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE INSERT AT THE ATHLETE","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public Boolean deleteAthlete(String idAthlete){

	try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "DELETE FROM athlete WHERE id_athlete = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, idAthlete);
            ps.execute();
            JOptionPane.showMessageDialog(null,"ATHLETE DELETE","SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE DELETE THE INFORMATION ABOUT THE ATHLETE","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public Boolean updateAthlete(String id, String athlete_name, String fatherSurname,String motherSurname, String gender, String favorite_contact, String birthdate 
    ,String cellphone_number, String telephone_home, String email){

	try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "UPDATE athlete SET athlete_name = ?, father_surname = ?, mother_surname = ?, gender = ?, favorite_contact = ?, birthdate = ?,"
            + " cellphone_number = ?, telephone_home = ?, email = ? WHERE id_person = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, athlete_name);
            ps.setString(2, fatherSurname);
            ps.setString(3, motherSurname);
            ps.setString(4, gender);
            ps.setString(5, favorite_contact);
            ps.setString(6, birthdate);
            ps.setString(7, cellphone_number);
            ps.setString(8, telephone_home);
            ps.setString(9, email);
            ps.setString(10,   id);
            ps.execute();
            JOptionPane.showMessageDialog(null,"ATHLETE UPDATE","SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE UPDATE THE INFORMATION ABOUT THE ATHLETE   ","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }  
   
}
