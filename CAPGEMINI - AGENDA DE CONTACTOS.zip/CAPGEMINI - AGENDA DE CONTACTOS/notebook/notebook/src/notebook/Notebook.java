
package notebook;

import controller.*;
import view.*;

public class Notebook {
    
    public static void main(String[] args) {
        
       VLogin login = new VLogin();
       VMenu   menu = new  VMenu();
       CLogin system = new CLogin(login, menu);
       login.setVisible(true);
   
    }
}
