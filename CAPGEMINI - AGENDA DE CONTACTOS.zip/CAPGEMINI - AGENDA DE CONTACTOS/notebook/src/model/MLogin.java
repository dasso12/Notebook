
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import view.*;
import controller.*;
import javax.swing.JOptionPane;

public class MLogin extends MConnection{
    VMenu       menu = null;
    VLogin     login = null;
    VDoctor   doctor = null;
    CAthlete athlete = null;
    private String user_name;
    private String pass_name;
    
    private void screen(){
        VAthlete a = new VAthlete();
        VMenu    m = new    VMenu();
        VPerson  p = new  VPerson();
        VDoctor  d = new  VDoctor();
        CMenu   main = new CMenu( m,a, p, d );
        m.setVisible(true); 
        CPerson cPerson   = new CPerson(p);
        CDoctor cDoctor   = new CDoctor(d);
        CAthlete cAthlete = new CAthlete(a);
    }
    
    public void searchUser(String username, String password){
    menu   = new  VMenu();
    login  = new VLogin();
    doctor = new VDoctor();
    boolean exist = false;   
	try{
            PreparedStatement ps    = null;
            Connection conn = connection();
            String query = "SELECT * FROM login WHERE user_name = ? AND pass_name = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet res = ps.executeQuery();
            
            while(res.next()){
                exist = true;
                user_name = res.getString("user_name");
		pass_name = res.getString("pass_name");
            }
            
            if(user_name!= null && pass_name != null ){
                JOptionPane.showMessageDialog(null,"WELCOME TO NOTEBOOK","HELLO!",JOptionPane.INFORMATION_MESSAGE);
                menu.setVisible(true);
                this.screen();
                finallyConnection();
            }  
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"THE USER NOT EXIST",":(",JOptionPane.ERROR_MESSAGE);
        }
    }    
}

