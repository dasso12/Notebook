
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class MPerson extends MConnection{
    
    public Boolean insertPerson(String name, String fatherSurname,String motherSurname, String adress, String favorite_contact, String occupation 
    ,String cellphone_number, String telephone_home, String email){

	try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "INSERT INTO person (person_name, father_surname, mother_surname, adress, favorite_contact, occupation,"
            + " cellphone_number, telephone_home, email) VALUES (?,?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, fatherSurname);
            ps.setString(3, motherSurname);
            ps.setString(4, adress);
            ps.setString(5, favorite_contact);
            ps.setString(6, occupation);
            ps.setString(7, cellphone_number);
            ps.setString(8, telephone_home);
            ps.setString(9, email);
            ps.execute();
            JOptionPane.showMessageDialog(null,"PERSON INSERT","SUCCESSFULL",JOptionPane.INFORMATION_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE INSERT AT THE PERSON","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }   
    
    public Boolean deletePerson(String idPerson){

	try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "DELETE FROM person WHERE id_person = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, idPerson);
            ps.execute();
            JOptionPane.showMessageDialog(null,"PERSON DELETE","SUCCESSFULL",JOptionPane.INFORMATION_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE DELETE THE INFORMATION ABOUT THE PERSON","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }   
    
     public Boolean updatePerson(String id, String name, String fatherSurname,String motherSurname, String adress, String favorite_contact, String occupation 
    ,String cellphone_number, String telephone_home, String email){

	try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "UPDATE person SET person_name = ?, father_surname = ?, mother_surname = ?, adress = ?, favorite_contact = ?, occupation = ?,"
            + " cellphone_number = ?, telephone_home = ?, email = ? WHERE id_person = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, fatherSurname);
            ps.setString(3, motherSurname);
            ps.setString(4, adress);
            ps.setString(5, favorite_contact);
            ps.setString(6, occupation);
            ps.setString(7, cellphone_number);
            ps.setString(8, telephone_home);
            ps.setString(9, email);
            ps.setString(10,   id);
            ps.execute();
            JOptionPane.showMessageDialog(null,"PERSON UPDATE","SUCCESSFULL",JOptionPane.INFORMATION_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE UPDATE THE INFORMATION ABOUT THE PERSON","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }   
}

