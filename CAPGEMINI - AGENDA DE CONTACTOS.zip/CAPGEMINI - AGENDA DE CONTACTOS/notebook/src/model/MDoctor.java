package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class MDoctor extends MConnection{
    
    public Boolean insertDoctor(String name,String fatherSurname,String motherSurname,String birthdate,String  hospital_name ,String  hospital_address,
    String specialty , String phone,String email){

	try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "INSERT INTO doctor (doctor_name, father_surname, mother_surname, birthdate, hospital_name, hospital_adress, cellphone_number,"
            + " telephone_home, email) VALUES (?,?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, fatherSurname);
            ps.setString(3, motherSurname);
            ps.setString(4, birthdate);
            ps.setString(5, hospital_name);
            ps.setString(6, hospital_address);
            ps.setString(7, specialty);
            ps.setString(8, phone);
            ps.setString(9, email);
            ps.execute();
            JOptionPane.showMessageDialog(null,"DOCTOR INSERT","SUCCESSFULL",JOptionPane.INFORMATION_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE INSERT AT THE DOCTOR","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }   
    
    public Boolean deleteDoctor(String idPerson){

	try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "DELETE FROM doctor WHERE id_doctor = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, idPerson);
            ps.execute();
            JOptionPane.showMessageDialog(null,"DOCTOR DELETE","SUCCESSFULL",JOptionPane.INFORMATION_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE DELETE THE INFORMATION ABOUT THE DOCTOR","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }   
    
     public Boolean updateDoctor(String id, String name,String fatherSurname,String motherSurname,String birthdate,String  hospital_name ,String  hospital_address,
    String specialty , String phone,String email){

	try{
            PreparedStatement ps = null;
            Connection conn = connection();
            String query = "UPDATE doctor SET doctor_name = ? , father_surname = ?, mother_surname = ?, birthdate = ?, hospital_name = ?, hospital_adress = ?, "
            + "cellphone_number = ?, telephone_home = ?, email = ? WHERE id_doctor = ?";
             ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, fatherSurname);
            ps.setString(3, motherSurname);
            ps.setString(4, birthdate);
            ps.setString(5, hospital_name);
            ps.setString(6, hospital_address);
            ps.setString(7, specialty);
            ps.setString(8, phone);
            ps.setString(9, email);
            ps.setString(10,   id);
            ps.execute();
            JOptionPane.showMessageDialog(null,"DOCTOR UPDATE","SUCCESSFULL",JOptionPane.INFORMATION_MESSAGE);
            return true;
	} 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null,"NOT IS POSSIBLE UPDATE THE INFORMATION ABOUT THE DOCTOR","NOT SUCCESSFULL",JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }   
}

