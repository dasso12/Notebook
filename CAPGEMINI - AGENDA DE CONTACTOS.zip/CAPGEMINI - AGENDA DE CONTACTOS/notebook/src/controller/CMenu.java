package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import  view.*;

public class CMenu implements ActionListener{
    private final VAthlete vAthlete;
    private VMenu       vMenu;
    private VPerson     vPerson;
    private VDoctor     vDoctor;
    //CONTRUCTOR METHOD.
    public   CMenu(VMenu menu, VAthlete athlete, VPerson person, VDoctor doctor)  
    {
        this.vMenu    =    menu;
        this.vAthlete = athlete;
        this.vPerson  =  person;
        this.vDoctor  =  doctor;
        this.vMenu.btnVAthelete.addActionListener(this); 
        this.vMenu.btnVPerson.addActionListener(this); 
        this.vMenu.btnVDoctor.addActionListener(this);
    }
    
    //METHOD WHOSE CONTENT ARE CLIC EVENTS.
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vMenu.btnVAthelete)
        {
            this.vAthlete.setVisible(true);
        }
        
        if(e.getSource() == vMenu.btnVPerson)
        {
            this.vPerson.setVisible(true);
        }
        
        if(e.getSource() == vMenu.btnVDoctor)
        {
            this.vDoctor.setVisible(true);
        }
    }
}
