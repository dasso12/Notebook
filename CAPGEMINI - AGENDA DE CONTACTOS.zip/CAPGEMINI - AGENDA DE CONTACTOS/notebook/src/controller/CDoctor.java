package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import  view.*;
import model.*;

public class CDoctor implements ActionListener{
    MConnection conn;
    private final VDoctor vDoctor;
    private MDoctor mDoctor;
    private VMenu     vMenu;
    private String  id_doctor;  
    private String  name;  
    private String  fatherSurname;
    private String  motherSurname;
    private String  birthday;
    private String  specialty;
    private String  hospital_name;
    private String  hospital_address;
    private String  phone;
    private String  email;
    
    //CONTRUCTOR METHOD.
    public   CDoctor(VDoctor doctor)
    {
        this.vDoctor = doctor;
        this.vDoctor.btnInsertDoctor.addActionListener(this);
        this.vDoctor.btnDeleteDoctor.addActionListener(this);
        this.vDoctor.btnUpdateDoctor.addActionListener(this);
    }
    
    //METHOD WHOSE CONTENT ARE CLIC EVENTS.
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vDoctor.btnInsertDoctor)
        {
            try
            {
                mDoctor = new MDoctor();
                name = vDoctor.txtDoctorName.getText();
                fatherSurname = vDoctor.txtFatherSurname.getText();
                motherSurname = vDoctor.txtMotherSurname.getText();
                birthday  = vDoctor.txtMotherSurname.getText();
                hospital_name = vDoctor.txtHospitalName.getText();
                hospital_address = vDoctor.txtHospitalAddress.getText();
                specialty = vDoctor.txtSpecialty.getText();
                phone = vDoctor.txtPhone.getText();
                email = vDoctor.txtEmail.getText();
                if(name.isEmpty() || fatherSurname.isEmpty() || birthday.isEmpty() || specialty.isEmpty())
                {
                   JOptionPane.showMessageDialog(null,"THE NAME, FATHER SURNAME, BIRTHDAY AND SPECIALTY ARE REQUIERED","WARNING",JOptionPane.ERROR_MESSAGE);
                   conn.finallyConnection();
                }
                else
                {
                   mDoctor.insertDoctor(name, fatherSurname, motherSurname, birthday, hospital_name , hospital_address, specialty ,phone, email);   
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        if(e.getSource() == vDoctor.btnDeleteDoctor)
        {
             try
            {
                mDoctor = new MDoctor();
                id_doctor = String.valueOf(vDoctor.txtIdDoctor.getText());
                if(id_doctor.isEmpty())
                {
                   JOptionPane.showMessageDialog(null,"WARNING, YOU SHOULD INSERT THE ID","WARNING",JOptionPane.ERROR_MESSAGE);
                   conn.finallyConnection();
                }
                else
                {
                    mDoctor.deleteDoctor(id_doctor);
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        if(e.getSource() == vDoctor.btnUpdateDoctor)
        {
            try
            {
                mDoctor = new MDoctor();
                id_doctor = String.valueOf(vDoctor.txtIdDoctor.getText());
                name = vDoctor.txtDoctorName.getText();
                fatherSurname = vDoctor.txtFatherSurname.getText();
                motherSurname = vDoctor.txtMotherSurname.getText();
                birthday  = vDoctor.txtMotherSurname.getText();
                hospital_name = vDoctor.txtHospitalName.getText();
                hospital_address = vDoctor.txtHospitalAddress.getText();
                specialty = vDoctor.txtSpecialty.getText();
                phone = vDoctor.txtPhone.getText();
                email = vDoctor.txtEmail.getText();
                if(id_doctor.isEmpty())
                {
                   JOptionPane.showMessageDialog(null,"WARNING, YOU SHOULD INSERT THE ID","WARNING",JOptionPane.ERROR_MESSAGE);
                   conn.finallyConnection();
                }
                else
                {
                   mDoctor.updateDoctor(id_doctor, name, fatherSurname, motherSurname, birthday, hospital_name , hospital_address, specialty ,phone, email);   
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
    }
}

