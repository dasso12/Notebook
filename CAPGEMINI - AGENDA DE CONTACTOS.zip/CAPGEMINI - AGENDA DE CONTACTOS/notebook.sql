-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2019 at 07:54 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `notebook`
--

-- --------------------------------------------------------

--
-- Table structure for table `athlete`
--

CREATE TABLE `athlete` (
  `id_athlete` int(11) NOT NULL,
  `athlete_name` varchar(20) NOT NULL,
  `father_surname` varchar(25) NOT NULL,
  `mother_surname` varchar(25) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `birthdate` varchar(15) DEFAULT NULL,
  `cellphone_number` varchar(45) DEFAULT NULL,
  `telephone_home` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id_doctor` int(11) NOT NULL,
  `doctor_name` varchar(20) NOT NULL,
  `father_surname` varchar(25) NOT NULL,
  `mother_surname` varchar(25) DEFAULT NULL,
  `birthdate` varchar(15) NOT NULL,
  `hospital_name` varchar(55) DEFAULT NULL,
  `hospital_adress` varchar(90) DEFAULT NULL,
  `cellphone_number` varchar(45) DEFAULT NULL,
  `telephone_home` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `graduate`
--

CREATE TABLE `graduate` (
  `id_graduate` int(11) NOT NULL,
  `graduate_name` varchar(20) NOT NULL,
  `father_surname` varchar(25) NOT NULL,
  `mother_surname` varchar(25) DEFAULT NULL,
  `office_telephone` varchar(25) DEFAULT NULL,
  `schedule_of_attention` varchar(45) NOT NULL,
  `cellphone_number` varchar(45) DEFAULT NULL,
  `telephone_home` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id_user` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `pass_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id_user`, `user_name`, `pass_name`) VALUES
(1, '12345678', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `id_person` int(11) NOT NULL,
  `person_name` varchar(20) DEFAULT NULL,
  `father_surname` varchar(25) NOT NULL,
  `mother_surname` varchar(25) DEFAULT NULL,
  `adress` varchar(90) NOT NULL,
  `favorite_contact` varchar(20) DEFAULT NULL,
  `occupation` varchar(30) NOT NULL,
  `cellphone_number` varchar(45) DEFAULT NULL,
  `telephone_home` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id_student` int(11) NOT NULL,
  `student_name` varchar(20) NOT NULL,
  `father_surname` varchar(25) NOT NULL,
  `mother_surname` varchar(25) DEFAULT NULL,
  `country_of_birth` varchar(60) NOT NULL,
  `city_of_birth` varchar(60) NOT NULL,
  `birthdate` varchar(15) DEFAULT NULL,
  `career` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cellphone_number` varchar(45) DEFAULT NULL,
  `telephone_home` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `athlete`
--
ALTER TABLE `athlete`
  ADD PRIMARY KEY (`id_athlete`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id_doctor`);

--
-- Indexes for table `graduate`
--
ALTER TABLE `graduate`
  ADD PRIMARY KEY (`id_graduate`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id_person`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id_student`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `athlete`
--
ALTER TABLE `athlete`
  MODIFY `id_athlete` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id_doctor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `graduate`
--
ALTER TABLE `graduate`
  MODIFY `id_graduate` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `id_person` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id_student` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
